const { app, BrowserWindow, ipcMain } = require('electron')
const { SerialManager } = require('./main-src/serial-manager')
const { BluetoothManager } = require('./main-src/bluetooth-manager')
const path = require('path')

/**
 * Configuration and environment variables
 */
process.env.VERBOSE_BLE_SCAN_OUTPUT = false

/**
 * Global variables
 */
// Necessary BroswerWindows 
var mainWindow
var serialSettingsWindow
var bleSettingsWindow

/**
 * Event listeners
 */
app.whenReady().then(() => {
    // Handle events from renderer
    ipcMain.handle('serial:getPorts', SerialManager.getPorts)
    ipcMain.handle('serial:closePort', SerialManager.closePort)
    ipcMain.handle('window:openSerialSettings', createSerialSettingsWindow)
    ipcMain.on('serial:openPort', handleOpenPort)
    ipcMain.on('serial:closePort', handleClosePort)
    ipcMain.on('serial:triggerStateUpdate', handleTriggerSerialStateUpdate)
    ipcMain.on('ble:deviceSelect', handleBleDeviceSelected)

    // Create the main window
    createWindow()
    // createSerialSettingsWindow()
    // createBleSettingsWindow()
    
    SerialManager.onData(serialOnData)
    SerialManager.onPortStateChange(serialPortStateChanged)
    
    BluetoothManager.onBleDeviceListUpdate(bleDeviceListUpdated)
    BluetoothManager.selectBrowserWindowForEvents(mainWindow)
    BluetoothManager.launchDevicePickerCallback(createBleSettingsWindow)
})

app.on('window-all-closed', () => {
    SerialManager.closePort()
    process.exit()
})

/**
 * Functions
 */

/** Window creation */
function createWindow() {
    mainWindow = new BrowserWindow({
        minWidth: 1280,
        minHeight: 720,
        titleBarStyle: 'hidden',
        titleBarOverlay: {
            color: '#4e4e4e',
            symbolColor: '#ffffff',
            height: 36
        },
        fullscreenable: false,
        webPreferences: {
            preload: path.join(__dirname, '/main-src/preload-main.js')
        }
    })

    mainWindow.loadFile('./renderer-src/index.html')
}

function createSerialSettingsWindow() {
    if (serialSettingsWindow) {
        serialSettingsWindow.show()
        return
    }

    serialSettingsWindow = new BrowserWindow({
        minWidth: 320,
        minHeight: 320,
        width: 320,
        height: 320,
        titleBarStyle: 'hidden',
        titleBarOverlay: {
            color: '#4E4E4E',
            symbolColor: '#ffffff',
            height: 32
        },
        fullscreenable: false,
        webPreferences: {
            preload: path.join(__dirname, '/main-src/preload-serial-settings.js')
        },
        parent: mainWindow
    })

    serialSettingsWindow.loadFile('./renderer-src/serial-settings-window.html')

    serialSettingsWindow.on('close', () => {
        serialSettingsWindow = null  
    })

    serialSettingsWindow.on('closed', () => {
        serialSettingsWindow = null  
    })
}

function createBleSettingsWindow() {
    if (bleSettingsWindow) {
        bleSettingsWindow.show()
        return
    }

    bleSettingsWindow = new BrowserWindow({
        minWidth: 320,
        minHeight: 290,
        width: 320,
        height: 290,
        // titleBarStyle: 'hidden',
        // titleBarOverlay: {
        //     color: '#4E4E4E',
        //     symbolColor: '#ffffff',
        //     height: 32
        // },
        frame: false,
        fullscreenable: false,
        webPreferences: {
            preload: path.join(__dirname, '/main-src/preload-ble-settings.js')
        },
        parent: mainWindow
    })

    bleSettingsWindow.loadFile('./renderer-src/ble-settings-window.html')

    bleSettingsWindow.on('close', () => {
        bleSettingsWindow = null
        BluetoothManager.removeSelectedBrowserWindow()
    })

    bleSettingsWindow.on('closed', () => {
        bleSettingsWindow = null
        BluetoothManager.removeSelectedBrowserWindow()
    })
}

/** Handlers */
function handleOpenPort(event, args) {
    SerialManager.openPort(args.path, args.baudRate)
}

function handleClosePort(event) {
    SerialManager.closePort()
}

function handleTriggerSerialStateUpdate() {
    serialPortStateChanged(SerialManager.getActivePortState())
}

function handleBleDeviceSelected(event, data) {
    console.log(data)
    BluetoothManager.selectDevice(data)
}

function serialPortStateChanged(state) {
    let data = {
        path: SerialManager.getActivePortPath(),
        baudRate: SerialManager.getActivePortBaudRate(),
        state: state
    }
    if (serialSettingsWindow) {
        // Serial device picker may be closed during port state changes
        serialSettingsWindow.webContents.send('serial:portStateUpdate', data)
    }
    mainWindow.webContents.send('serial:portStateUpdate', data)
}

function bleDeviceListUpdated(deviceList) {
    bleSettingsWindow.webContents.send('ble:deviceListUpdate', deviceList)
}

function serialOnData(data) {
    console.log(data)
    mainWindow.webContents.send('serial:data', data)
}