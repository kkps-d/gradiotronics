/**
 * serial-control.js
 * Contains comment templates for js files
 */

/**
 * Elements
 */

/**
 * Event listeners
 */

/**
 * Functions
 */