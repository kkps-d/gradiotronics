const { contextBridge, ipcRenderer } = require('electron')

contextBridge.exposeInMainWorld('electronAPI', {
    getPorts: () => ipcRenderer.invoke('serial:getPorts'),
    openPort: args => ipcRenderer.send('serial:openPort', args),
    closePort: () => ipcRenderer.send('serial:closePort'),
    triggerSerialPortStateUpdate: () => ipcRenderer.send('serial:triggerStateUpdate'),
    serialPortStateUpdate: callback => ipcRenderer.on('serial:portStateUpdate', callback)
})