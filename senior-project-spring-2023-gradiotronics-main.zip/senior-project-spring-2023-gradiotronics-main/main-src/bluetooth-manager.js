/**
 * ble-manager.js
 * Helps the BluetoothHandler which allows the user to pick a device and also remembers which device has been last picked
 */

/**
 * Device selection process adapted from the following
 * https://github.com/grosdode/Electron-multible-BLE-devices
 */

class BluetoothManager {
    static #browserWindowForEvents
    static #callbackToLaunchDevicePickerWindow
    static #callbackForBluetoothEvent
    static #onBleDeviceListUpdateCallback
    static #currentDevicesList = {}

    // Select a BroswerWindow that the 'select-bluetooth-device' event will be registered to
    static selectBrowserWindowForEvents(browserWindow) {
        this.#browserWindowForEvents = browserWindow

        let callbackForBluetoothEventWrapper = (event, deviceList, callback) => {
            this.#callbackToLaunchDevicePickerWindow()
            this.#selectBluetoothDeviceEventCallback(event, deviceList, callback)
        }

        // Register needed events to this window
        this.#browserWindowForEvents.webContents.on('select-bluetooth-device', callbackForBluetoothEventWrapper)
    }

    // Register callback to launch a browser window that contains a device picker that will be launched when 'select-bluetooth-device' is fired
    static launchDevicePickerCallback(callback) {
        this.#callbackToLaunchDevicePickerWindow = callback
    }

    // This function is run when a user selects a device through the Web UI
    static selectDevice(data) {
        // Clear the device list
        this.#currentDevicesList = {}

        // Verify data
        let deviceId, rememberDevice

        let error = false

        if (!data) {
            console.log('[BluetoothManager] Data is unavailable when selecting device, ignoring')
            error = true
        }

        if (!error && (data.deviceId == null || data.rememberDevice == null)) {
            console.log('[BluetoothManager] Data format is wrong, ignoring')
            error = true
        }

        if (!error && (!data.deviceId.match('(([A-F]|[0-9]){2}:?){6}'))) {
            console.log('[BluetoothManager] Invalid Bluetooth MAC to select')
            error = true
        }

        if (error == true) {
            this.#callbackForBluetoothEvent("")
            return
        }

        deviceId = data.deviceId

        if (data.rememberDevice == true) {
            rememberDevice = true
        } else {
            rememberDevice = false
        }

        if (!this.#callbackForBluetoothEvent) {
            console.log('[BluetoothManager] CRITICAL: #callbackForBluetoothEvent has not been registered! Something is very wrong with getting a callback from \'select-bluetooth-device\' event. Exiting')
            process.exit(1)
        }

        this.#callbackForBluetoothEvent(deviceId)
    }

    static removeSelectedBrowserWindow() {
        this.#browserWindowForEvents = null
    }

    static onBleDeviceListUpdate(callback) {
        this.#onBleDeviceListUpdateCallback = callback
    }

    static #selectBluetoothDeviceEventCallback(event, deviceList, callback) {
        event.preventDefault()
        this.#callbackForBluetoothEvent = callback

        if (!deviceList) {
            return
        }

        deviceList.forEach(device => {
            if (!device.deviceName.includes("Unknown")) {
                this.#currentDevicesList[device.deviceId] = device.deviceName
            }
        })

        if (process.env.VERBOSE_BLE_SCAN_OUTPUT == true) {
            console.log('====== Devices ======')
            console.log(this.#currentDevicesList)
            console.log('=====================')
        } else {
            console.log(`[BluetoothManager] Scan in progress, ${Object.keys(this.#currentDevicesList).length} devices found.`)
        }

        // Run callbacks in a wrapper
        (deviceList => {
            if (this.#onBleDeviceListUpdateCallback) {
                this.#onBleDeviceListUpdateCallback(deviceList)
            } else {
                console.log('[BluetoothManager] CRITICAL: onBleDeviceListUpdateCallback not registered! Exiting')
                process.exit(1)
            }
        })(this.#currentDevicesList)
    }
}

module.exports.BluetoothManager = BluetoothManager