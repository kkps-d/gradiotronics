const { contextBridge, ipcRenderer } = require('electron')

contextBridge.exposeInMainWorld('electronAPI', {
    // Open serial settings window
    openSerialSettings: () => ipcRenderer.invoke('window:openSerialSettings'),
    serialPortStateUpdate: callback => ipcRenderer.on('serial:portStateUpdate', callback),
    onSerialData: callback => ipcRenderer.on('serial:data', callback)
})