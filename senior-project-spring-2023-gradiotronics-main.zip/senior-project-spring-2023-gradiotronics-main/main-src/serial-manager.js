/**
 * serial-manager.js
 * Contains the SerialManager class and code for its functionality
 */

const { SerialPort } = require('serialport')
const { ReadlineParser } = require('@serialport/parser-readline')

/**
 * @todo Bug in SerialManager where failing to open a port, and then closing the serialmanager window can falsely display that the failed port is opened
 */

class SerialManager {
    static #activePort = null
    static #onDataCallback
    static #onDataWrapper
    static #onPortStateChangeCallback
    static #onPortOpenWrapper
    static #onPortCloseWrapper
    static #parser

    static async getPorts() {
        let ports = await SerialPort.list()
        console.log('[SerialManager] Listing available ports')
        ports.forEach(port => {console.log(port.friendlyName)})
        return ports
    }

    static getActivePortPath() {
        if (this.#activePort) {
            return this.#activePort.path
        } else {
            return 'None'
        }
    }

    static getActivePortBaudRate() {
        if (this.#activePort) {
            return this.#activePort.baudRate
        } else {
            return -1
        }
    }

    static getActivePortState() {
        if (this.#activePort) {
            if (this.#activePort.open) {
                return 'open'
            } else {
                return 'close'
            }
        } else {
            return 'close'
        }
    }

    static openPort(path, baudRate) {
        console.log(`[SerialManager] Trying to open port ${path} at ${baudRate} baud`)
        this.#activePort = new SerialPort({
            path: path,
            baudRate: parseInt(baudRate)
        }, e => {
            if (e) {
                console.log(`[SerialManager] Unable to open port. ${e}.`)
            }
            return false
        })

        this.#parser = this.#activePort.pipe(new ReadlineParser({ delimiter: '\r\n' }))

        this.#onDataWrapper = data => {
            if (this.#onDataCallback) {
                this.#onDataCallback(data)
            } else {
                console.log('[SerialManager] CRITICAL: onDataCallback not registered! Exiting')
                process.exit(1)
            }
        }

        this.#onPortOpenWrapper = () => {
            if (this.#onPortStateChangeCallback) {
                this.#onPortStateChangeCallback('open')
            } else {
                console.log('[SerialManager] CRITICAL: onPortStateChangeCallback not registered! Exiting')
                process.exit(1)
            }
            console.log(`[SerialManager] ${this.#activePort.path} is now active`)
        }

        this.#onPortCloseWrapper = () => {
            if (this.#onPortStateChangeCallback) {
                this.#onPortStateChangeCallback('close')
            } else {
                console.log('[SerialManager] CRITICAL: onPortStateChangeCallback not registered! Exiting')
                process.exit(1)
            }
            this.closePort()
        }

        this.#parser.on('data', this.#onDataWrapper)

        this.#activePort.on('open', this.#onPortOpenWrapper)

        this.#activePort.on('close', this.#onPortCloseWrapper)

        return true
    }

    static closePort() {
        // Ensures port is closed when Arduino is disconnected for any reason
        if (this.#activePort != null) {
            console.log(`[SerialManager] Closing ${this.#activePort.path}`)
            if (this.#activePort.isOpen) {
                this.#activePort.close()
            }
            this.#activePort = null
        } else {
            console.log(`[SerialManager] No port is open. No port is closed`)
        }

        if (this.#parser != null) {
            this.#parser.removeListener('data', this.#onDataWrapper)
            this.#parser = null
        }
    }

    static onData(callback) {
        this.#onDataCallback = callback
    }

    static onPortStateChange(callback) {
        this.#onPortStateChangeCallback = callback
    }
}

module.exports.SerialManager = SerialManager