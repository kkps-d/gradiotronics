const { contextBridge, ipcRenderer } = require('electron')

contextBridge.exposeInMainWorld('electronAPI', {
    selectBleDevice: data => ipcRenderer.send('ble:deviceSelect', data),
    bleDeviceListUpdate: callback => ipcRenderer.on('ble:deviceListUpdate', callback),
})