/**
 * serial-settings-window main.js
 * Contains functionality for pop-up serial settings window
 */

/**
 * Elements
 */
const serialPortSelect = document.getElementById('serial-port-select')
const baudRateSelect = document.getElementById('baud-rate-select')
const refreshPortsBtn = document.getElementById('refresh-ports-btn')
const connectPortBtn = document.getElementById('connect-port-btn')
const deviceStatusText = document.getElementById('device-status-text')

/**
 * Event listeners
 */
window.onload = async function () {
    updateAvailablePorts()
    window.electronAPI.triggerSerialPortStateUpdate()
}

window.electronAPI.serialPortStateUpdate(serialPortStateUpdate)

refreshPortsBtn.addEventListener('click', () => {
    updateAvailablePorts(true)
})

connectPortBtn.addEventListener('click', () => {
    if (connectPortBtn.innerText == 'Connect') {
        openSelectedPort(true)
    } else if (connectPortBtn.innerText == 'Disconnect') {
        closePort(true)
    }
})

/**
 * Functions
 */
async function updateAvailablePorts(triggeredByButton = false) {
    serialPortSelect.innerHTML = ""
    let ports = await window.electronAPI.getPorts()
    if (ports.length > 0) {
        ports.forEach(port => {
            let tempOption = document.createElement("option")
            tempOption.text = port.friendlyName
            tempOption.value = port.path
            serialPortSelect.options.add(tempOption)
        });
        connectPortBtn.disabled = false
    } else {
        let tempOption = document.createElement("option")
        tempOption.text = "No ports available"
        tempOption.value = "NONE"
        connectPortBtn.disabled = true
    }

    if (triggeredByButton) {
        refreshPortsBtn.innerText = 'Refresh ports ✅'
        setTimeout(() => {
            refreshPortsBtn.innerText = 'Refresh ports'
        }, 3000)
    }
}

let portActiveTimeout

function openSelectedPort(triggeredByButton = false) {
    let selectedPortPath = serialPortSelect.options[serialPortSelect.selectedIndex].value
    let selectedBaudRate = baudRateSelect.options[baudRateSelect.selectedIndex].text
    window.electronAPI.openPort({
        path: selectedPortPath,
        baudRate: selectedBaudRate
    })

    if (triggeredByButton) {
        connectPortBtn.innerText = 'Connecting ⌛'
        portActiveTimeout = setTimeout(() => {
            connectPortBtn.innerText = 'Failed to connect ❌'
            setTimeout(() => {
                connectPortBtn.innerText = 'Connect'
            }, 2000)
        }, 5000)
    }
}

function closePort(triggeredByButton = false) {
    window.electronAPI.closePort()

    if (triggeredByButton) {
        connectPortBtn.innerText = 'Disconnecting ⌛'
        portActiveTimeout = setTimeout(() => {
            connectPortBtn.innerText = 'Failed to disconnect ❌'
            setTimeout(() => {
                connectPortBtn.innerText = 'Disconnect'
            }, 2000)
        }, 5000)
    }
}

function serialPortStateUpdate(_event, data) {
    let state = data.state
    if (state == 'open') {
        clearTimeout(portActiveTimeout)
        connectPortBtn.innerText = 'Connected ✅'
        deviceStatusText.innerText = `Connected to ${data.path}`
        setTimeout(() => {
            connectPortBtn.innerText = 'Disconnect'
        }, 2000)
    } else if (state == 'close') {
        clearTimeout(portActiveTimeout)
        connectPortBtn.innerText = 'Disconnected ✅'
        deviceStatusText.innerText = `Not connected`
        setTimeout(() => {
            connectPortBtn.innerText = 'Connect'
        }, 2000)
    }
}