/**
 * main-window main.js
 * Contains functionality for main window
 */


/**
 * Elements
 */


/**
 * Event listeners
 */

/**
 * Functions
 */

