/**
 * ble-settings-window main.js
 * Contains functionality for the ble device picker window
 */

/**
 * Elements
 */
const bleDeviceSelect = document.getElementById('ble-device-select')
const connectDeviceBtn = document.getElementById('connect-device-btn')
const cancelBtn = document.getElementById('cancel-btn')

/**
 * Event listeners
 */
window.onload = function () {

}

window.electronAPI.bleDeviceListUpdate(bleDeviceListUpdate)

connectDeviceBtn.addEventListener('click', () => {
    // Send selected value in dropdown and remember checkbox to main
    let selectedDeviceId = bleDeviceSelect.value

    if (selectedDeviceId) {
        let dataToSend = {
            deviceId: selectedDeviceId,
            rememberDevice: false
        }

        console.log(dataToSend)

        window.electronAPI.selectBleDevice(dataToSend)
        window.close()
    }

})

cancelBtn.addEventListener('click', () => {
    window.electronAPI.selectBleDevice(null)
    window.close()
})

/**
 * Functions
 */
var previousDeviceList = {}
function bleDeviceListUpdate(_event, deviceList) {
    if (Object.keys(deviceList).length > 0 && (Object.keys(deviceList).length - Object.keys(previousDeviceList).length) > 0) {
        let deviceIds = Object.keys(deviceList)
        bleDeviceSelect.innerHTML = ""
        previousDeviceList = deviceList
        deviceIds.forEach(deviceId => {
            let tempOption = document.createElement("option")
            tempOption.text = `${deviceList[deviceId]} (${deviceId})`
            tempOption.value = deviceId
            bleDeviceSelect.options.add(tempOption)
        })
    }
}
